import json
import os
import cloudshell.api.cloudshell_api as api


# Production
reservation_details = json.loads(os.environ["RESERVATIONCONTEXT"])
resource_context = json.loads(os.environ['RESOURCECONTEXT'])
connectivity_details = json.loads(os.environ["QUALICONNECTIVITYCONTEXT"])


# username = connectivity_details['adminUser']
# password = connectivity_details['adminPass']
# server = connectivity_details['serverAddress']
# domain = reservation_details['domain']
#
# session = api.CloudShellAPISession(server, username, password, domain)
# debug:
# session = api.CloudShellAPISession('10.87.42.117', 'admin', 'admin', 'Global')




def executePlaybookScript():
    # AppName = os.environ['App_Name']
    attr_name = os.environ['Attribute_Name']
    attr_value = os.environ['New_Image_Name']
    auto_deploy = os.environ['Auto_deploy']
    edit_list = []
    session = api.CloudShellAPISession(host=connectivity_details['serverAddress'],
                                       token_id=connectivity_details['adminAuthToken'],
                                       domain=reservation_details['domain'])
    reservation_details_data = session.GetReservationDetails(reservation_details['id']).ReservationDescription
    return None