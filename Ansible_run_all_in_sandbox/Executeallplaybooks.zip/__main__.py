import ExecuteAllPlaybooks
myObject = ExecuteAllPlaybooks.AnsibleExecutioner()
myObject.executePlaybookScript()