import executePlaybookScript
myObject = executePlaybookScript.AnsibleExecutioner()
myObject.executePlaybookScript()
